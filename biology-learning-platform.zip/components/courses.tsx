import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Dna, HeartPulse, Baby, Shield, Microscope, Mountain } from "lucide-react"
import { BookOpen } from "lucide-react" // Import BookOpen icon

export default function Courses() {
  const courses = [
    {
      icon: HeartPulse,
      title: "الدعامة والحركة",
      description: "دراسة شاملة للجهاز العضلي والهيكلي وآليات الحركة في الكائنات الحية",
      image: "/human-muscular-system-anatomy-male-scientist.jpg",
      color: "text-primary",
    },
    {
      icon: Microscope,
      title: "التنسيق الهرموني",
      description: "فهم عميق للغدد الصماء والهرمونات ودورها في تنظيم وظائف الجسم",
      image: "/endocrine-system-hormones-medical-illustration.jpg",
      color: "text-secondary",
    },
    {
      icon: Baby,
      title: "التكاثر",
      description: "دراسة تفصيلية لأنواع التكاثر والتطور الجنيني في الكائنات الحية",
      image: "/cell-division-mitosis-meiosis-diagram.jpg",
      color: "text-accent",
    },
    {
      icon: Shield,
      title: "المناعة",
      description: "التعرف على الجهاز المناعي وآليات الدفاع عن الجسم ضد الأمراض",
      image: "/immune-system-antibodies-white-blood-cells.jpg",
      color: "text-primary",
    },
    {
      icon: Dna,
      title: "DNA + RNA",
      description: "دراسة الأحماض النووية والهندسة الوراثية والبيولوجيا الجزيئية",
      image: "/dna-double-helix-genetic-code-molecular-biology.jpg",
      color: "text-secondary",
    },
    {
      icon: Mountain,
      title: "جيولوجيا",
      description: "استكشاف علوم الأرض والصخور والمعادن والظواهر الجيولوجية",
      image: "/rock-formations-geological-layers-earth-science.jpg",
      color: "text-accent",
    },
  ]

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-4 text-balance">الدورات التعليمية</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            دورات شاملة ومتخصصة تغطي جميع جوانب منهج الأحياء والجيولوجيا
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map((course, index) => (
            <Card
              key={index}
              className="group hover:shadow-2xl transition-all duration-300 border-2 hover:border-primary/50 overflow-hidden"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={course.image || "/placeholder.svg"}
                  alt={course.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/50 to-transparent" />
              </div>
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className={`p-3 rounded-lg bg-primary/10`}>
                    <course.icon className={`h-6 w-6 ${course.color}`} />
                  </div>
                  <CardTitle className="text-2xl">{course.title}</CardTitle>
                </div>
                <CardDescription className="text-base leading-relaxed">{course.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <BookOpen className="h-4 w-4" />
                  <span>محتوى شامل ومفصل</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
