import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Facebook, MapPin, Mail } from "lucide-react"

export default function Contact() {
  return (
    <section className="py-20 bg-gradient-to-br from-primary/5 via-background to-secondary/5 leading-9">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-primary mb-4 text-balance">تواصل معنا</h2>
            <p className="text-xl text-muted-foreground leading-relaxed">
              ابدأ رحلتك التعليمية اليوم وحقق أحلامك الأكاديمية
            </p>
          </div>

          <Card className="shadow-2xl border-2">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-3xl mb-2">معلومات التواصل</CardTitle>
              <CardDescription className="text-lg">نحن هنا للإجابة على جميع استفساراتك</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="flex items-start gap-4 p-4 bg-muted/50 rounded-lg">
                  <MapPin className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-lg mb-1">العنوان</h3>
                    <p className="text-muted-foreground">مصر</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 bg-muted/50 rounded-lg">
                  <Mail className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-lg mb-1">البريد الإلكتروني</h3>
                    <a
                      href="mailto:01148766696m@gmail.com"
                      className="text-muted-foreground hover:text-primary transition-colors break-all"
                    >
                      01148766696m@gmail.com
                    </a>
                  </div>
                </div>
              </div>

              <div className="pt-6 border-t border-border">
                <Button
                  size="lg"
                  className="w-full text-lg py-6 bg-primary hover:bg-primary/90 text-primary-foreground"
                  asChild
                >
                  <a href="https://www.facebook.com/share/14TvrKoPeQV/" target="_blank" rel="noopener noreferrer">
                    <Facebook className="ml-2 h-5 w-5" />
                    تواصل معنا على فيسبوك
                  </a>
                </Button>
              </div>

              <div className="bg-primary/5 p-6 rounded-lg text-center">
                <p className="text-lg font-semibold text-primary mb-2">🎓 انضم إلى آلاف الطلاب المتفوقين</p>
                <p className="text-muted-foreground">خبرة 20 سنة في تحقيق التفوق الأكاديمي</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
