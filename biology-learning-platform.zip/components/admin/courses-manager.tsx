"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Plus, Save, Trash2, GripVertical, Video } from "lucide-react"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import Link from "next/link"

type Course = {
  id: string
  title: string
  description: string
  icon_name: string
  order_index: number
  is_active: boolean
}

export function CoursesManager({ initialCourses }: { initialCourses: Course[] }) {
  const [courses, setCourses] = useState<Course[]>(initialCourses)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [isAdding, setIsAdding] = useState(false)
  const [newCourse, setNewCourse] = useState({
    title: "",
    description: "",
    icon_name: "book-open",
    is_active: true,
  })
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()

  const handleUpdate = async (course: Course) => {
    const { error } = await supabase.from("courses").update(course).eq("id", course.id)

    if (error) {
      toast.error("حدث خطأ أثناء التحديث")
      return
    }

    toast.success("تم تحديث الدورة بنجاح")
    setEditingId(null)
    router.refresh()
  }

  const handleAdd = async () => {
    const maxOrder = Math.max(...courses.map((c) => c.order_index), 0)

    const { error } = await supabase.from("courses").insert({
      ...newCourse,
      order_index: maxOrder + 1,
    })

    if (error) {
      toast.error("حدث خطأ أثناء الإضافة")
      return
    }

    toast.success("تم إضافة الدورة بنجاح")
    setIsAdding(false)
    setNewCourse({ title: "", description: "", icon_name: "book-open", is_active: true })
    router.refresh()
  }

  const handleDelete = async (id: string) => {
    if (!confirm("هل أنت متأكد من حذف هذه الدورة؟")) return

    const { error } = await supabase.from("courses").delete().eq("id", id)

    if (error) {
      toast.error("حدث خطأ أثناء الحذف")
      return
    }

    toast.success("تم حذف الدورة بنجاح")
    router.refresh()
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">الدورات التعليمية</h2>
          <p className="text-gray-600 mt-1">إدارة محتوى الدورات المعروضة في الموقع</p>
        </div>
        <Button onClick={() => setIsAdding(true)} className="bg-gradient-to-r from-emerald-600 to-teal-600">
          <Plus className="w-4 h-4 ml-2" />
          إضافة دورة جديدة
        </Button>
      </div>

      {isAdding && (
        <Card>
          <CardHeader>
            <CardTitle>إضافة دورة جديدة</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="new-title">عنوان الدورة</Label>
              <Input
                id="new-title"
                value={newCourse.title}
                onChange={(e) => setNewCourse({ ...newCourse, title: e.target.value })}
                placeholder="مثال: الدعامة والحركة"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-description">وصف الدورة</Label>
              <Textarea
                id="new-description"
                value={newCourse.description}
                onChange={(e) => setNewCourse({ ...newCourse, description: e.target.value })}
                placeholder="وصف مختصر للدورة..."
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-icon">اسم الأيقونة</Label>
              <Input
                id="new-icon"
                value={newCourse.icon_name}
                onChange={(e) => setNewCourse({ ...newCourse, icon_name: e.target.value })}
                placeholder="book-open"
              />
              <p className="text-xs text-gray-500">استخدم أسماء أيقونات Lucide (مثل: book-open, dna, shield)</p>
            </div>
            <div className="flex items-center justify-between pt-4 border-t">
              <div className="flex items-center gap-2">
                <Switch
                  checked={newCourse.is_active}
                  onCheckedChange={(checked) => setNewCourse({ ...newCourse, is_active: checked })}
                />
                <Label>نشطة</Label>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsAdding(false)}>
                  إلغاء
                </Button>
                <Button onClick={handleAdd} disabled={!newCourse.title || !newCourse.description}>
                  إضافة
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {courses.map((course) => (
          <Card key={course.id}>
            <CardContent className="pt-6">
              {editingId === course.id ? (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>عنوان الدورة</Label>
                    <Input
                      value={course.title}
                      onChange={(e) =>
                        setCourses(courses.map((c) => (c.id === course.id ? { ...c, title: e.target.value } : c)))
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>وصف الدورة</Label>
                    <Textarea
                      value={course.description}
                      onChange={(e) =>
                        setCourses(courses.map((c) => (c.id === course.id ? { ...c, description: e.target.value } : c)))
                      }
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>اسم الأيقونة</Label>
                    <Input
                      value={course.icon_name}
                      onChange={(e) =>
                        setCourses(courses.map((c) => (c.id === course.id ? { ...c, icon_name: e.target.value } : c)))
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={course.is_active}
                        onCheckedChange={(checked) =>
                          setCourses(courses.map((c) => (c.id === course.id ? { ...c, is_active: checked } : c)))
                        }
                      />
                      <Label>نشطة</Label>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" onClick={() => setEditingId(null)}>
                        إلغاء
                      </Button>
                      <Button onClick={() => handleUpdate(course)}>
                        <Save className="w-4 h-4 ml-2" />
                        حفظ
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <GripVertical className="w-5 h-5 text-gray-400" />
                      <h3 className="text-lg font-semibold text-gray-900">{course.title}</h3>
                      {!course.is_active && (
                        <span className="px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded">غير نشطة</span>
                      )}
                    </div>
                    <p className="text-gray-600 mr-8">{course.description}</p>
                    <p className="text-sm text-gray-500 mt-2 mr-8">الأيقونة: {course.icon_name}</p>
                  </div>
                  <div className="flex gap-2">
                    <Link href={`/admin/courses/${course.id}`}>
                      <Button variant="default" size="sm" className="bg-gradient-to-r from-emerald-600 to-teal-600">
                        <Video className="w-4 h-4 ml-2" />
                        إدارة المحتوى
                      </Button>
                    </Link>
                    <Button variant="outline" size="sm" onClick={() => setEditingId(course.id)}>
                      تعديل
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(course.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
