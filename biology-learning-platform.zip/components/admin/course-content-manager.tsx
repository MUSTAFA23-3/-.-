"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import { ArrowLeft, Plus, Trash2, Edit, FileText, Video, Upload } from "lucide-react"
import Link from "next/link"

interface Lesson {
  id: string
  title: string
  description: string
  video_url: string
  order_index: number
  duration: number
  is_free: boolean
  is_active: boolean
}

interface CourseFile {
  id: string
  lesson_id: string
  title: string
  file_url: string
  file_type: string
  file_size: number
}

interface Course {
  id: string
  title: string
  description: string
}

export function CourseContentManager({ courseId }: { courseId: string }) {
  const [course, setCourse] = useState<Course | null>(null)
  const [lessons, setLessons] = useState<Lesson[]>([])
  const [files, setFiles] = useState<CourseFile[]>([])
  const [showLessonForm, setShowLessonForm] = useState(false)
  const [showFileForm, setShowFileForm] = useState(false)
  const [editingLesson, setEditingLesson] = useState<Lesson | null>(null)
  const [selectedLessonId, setSelectedLessonId] = useState<string>("")
  const [loading, setLoading] = useState(true)

  const [lessonForm, setLessonForm] = useState({
    title: "",
    description: "",
    video_url: "",
    duration: 0,
    is_free: false,
    order_index: 0,
  })

  const [fileForm, setFileForm] = useState({
    title: "",
    file_url: "",
    file_type: "pdf",
  })

  const supabase = getSupabaseBrowserClient()

  useEffect(() => {
    loadCourse()
    loadLessons()
    loadFiles()
  }, [courseId])

  const loadCourse = async () => {
    const { data } = await supabase.from("courses").select("*").eq("id", courseId).single()

    if (data) setCourse(data)
  }

  const loadLessons = async () => {
    setLoading(true)
    const { data } = await supabase
      .from("course_lessons")
      .select("*")
      .eq("course_id", courseId)
      .order("order_index", { ascending: true })

    if (data) setLessons(data)
    setLoading(false)
  }

  const loadFiles = async () => {
    const { data } = await supabase.from("course_files").select("*").eq("course_id", courseId)

    if (data) setFiles(data)
  }

  const handleSaveLesson = async () => {
    if (!lessonForm.title) {
      alert("الرجاء إدخال عنوان الدرس")
      return
    }

    const lessonData = {
      ...lessonForm,
      course_id: courseId,
      updated_at: new Date().toISOString(),
    }

    if (editingLesson) {
      await supabase.from("course_lessons").update(lessonData).eq("id", editingLesson.id)
    } else {
      await supabase.from("course_lessons").insert(lessonData)
    }

    setShowLessonForm(false)
    setEditingLesson(null)
    setLessonForm({ title: "", description: "", video_url: "", duration: 0, is_free: false, order_index: 0 })
    loadLessons()
  }

  const handleDeleteLesson = async (id: string) => {
    if (confirm("هل أنت متأكد من حذف هذا الدرس؟")) {
      await supabase.from("course_lessons").delete().eq("id", id)
      loadLessons()
    }
  }

  const handleSaveFile = async () => {
    if (!fileForm.title || !fileForm.file_url || !selectedLessonId) {
      alert("الرجاء ملء جميع الحقول واختيار درس")
      return
    }

    await supabase.from("course_files").insert({
      ...fileForm,
      course_id: courseId,
      lesson_id: selectedLessonId,
      file_size: 0,
    })

    setShowFileForm(false)
    setFileForm({ title: "", file_url: "", file_type: "pdf" })
    setSelectedLessonId("")
    loadFiles()
  }

  const handleDeleteFile = async (id: string) => {
    if (confirm("هل أنت متأكد من حذف هذا الملف؟")) {
      await supabase.from("course_files").delete().eq("id", id)
      loadFiles()
    }
  }

  const handleEditLesson = (lesson: Lesson) => {
    setEditingLesson(lesson)
    setLessonForm({
      title: lesson.title,
      description: lesson.description || "",
      video_url: lesson.video_url || "",
      duration: lesson.duration || 0,
      is_free: lesson.is_free,
      order_index: lesson.order_index,
    })
    setShowLessonForm(true)
  }

  if (loading) {
    return <div className="text-center py-12">جاري التحميل...</div>
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/admin/courses">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold">{course?.title}</h1>
            <p className="text-muted-foreground">{course?.description}</p>
          </div>
        </div>
      </div>

      {/* Lessons Section */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold flex items-center gap-2">
            <Video className="h-6 w-6" />
            الدروس والفيديوهات
          </h2>
          <Button
            onClick={() => {
              setEditingLesson(null)
              setLessonForm({
                title: "",
                description: "",
                video_url: "",
                duration: 0,
                is_free: false,
                order_index: lessons.length,
              })
              setShowLessonForm(true)
            }}
          >
            <Plus className="h-4 w-4 ml-2" />
            إضافة درس جديد
          </Button>
        </div>

        {showLessonForm && (
          <Card className="p-4 mb-6 bg-muted/50">
            <div className="space-y-4">
              <div>
                <Label>عنوان الدرس</Label>
                <Input
                  value={lessonForm.title}
                  onChange={(e) => setLessonForm({ ...lessonForm, title: e.target.value })}
                  placeholder="مثال: مقدمة في الدعامة والحركة"
                />
              </div>
              <div>
                <Label>وصف الدرس</Label>
                <Textarea
                  value={lessonForm.description}
                  onChange={(e) => setLessonForm({ ...lessonForm, description: e.target.value })}
                  placeholder="وصف تفصيلي للدرس"
                  rows={3}
                />
              </div>
              <div>
                <Label>رابط الفيديو (YouTube, Vimeo, etc.)</Label>
                <Input
                  value={lessonForm.video_url}
                  onChange={(e) => setLessonForm({ ...lessonForm, video_url: e.target.value })}
                  placeholder="https://www.youtube.com/watch?v=..."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>المدة (بالدقائق)</Label>
                  <Input
                    type="number"
                    value={lessonForm.duration}
                    onChange={(e) => setLessonForm({ ...lessonForm, duration: Number.parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div>
                  <Label>ترتيب الدرس</Label>
                  <Input
                    type="number"
                    value={lessonForm.order_index}
                    onChange={(e) =>
                      setLessonForm({ ...lessonForm, order_index: Number.parseInt(e.target.value) || 0 })
                    }
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="is_free"
                  checked={lessonForm.is_free}
                  onChange={(e) => setLessonForm({ ...lessonForm, is_free: e.target.checked })}
                  className="h-4 w-4"
                />
                <Label htmlFor="is_free">درس مجاني (متاح للجميع)</Label>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleSaveLesson}>{editingLesson ? "تحديث الدرس" : "إضافة الدرس"}</Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowLessonForm(false)
                    setEditingLesson(null)
                  }}
                >
                  إلغاء
                </Button>
              </div>
            </div>
          </Card>
        )}

        <div className="space-y-3">
          {lessons.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد دروس بعد. ابدأ بإضافة درس جديد!</p>
          ) : (
            lessons.map((lesson, index) => (
              <Card key={lesson.id} className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="font-semibold text-sm bg-primary/10 text-primary px-2 py-1 rounded">
                        الدرس {index + 1}
                      </span>
                      {lesson.is_free && (
                        <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">مجاني</span>
                      )}
                    </div>
                    <h3 className="font-semibold text-lg mb-1">{lesson.title}</h3>
                    <p className="text-sm text-muted-foreground mb-2">{lesson.description}</p>
                    {lesson.video_url && (
                      <a
                        href={lesson.video_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-primary hover:underline flex items-center gap-1"
                      >
                        <Video className="h-3 w-3" />
                        رابط الفيديو
                      </a>
                    )}
                    {lesson.duration > 0 && (
                      <p className="text-xs text-muted-foreground mt-1">المدة: {lesson.duration} دقيقة</p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="icon" onClick={() => handleEditLesson(lesson)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="destructive" size="icon" onClick={() => handleDeleteLesson(lesson.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </Card>

      {/* Files Section */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold flex items-center gap-2">
            <FileText className="h-6 w-6" />
            الملفات والمذكرات
          </h2>
          <Button onClick={() => setShowFileForm(true)} disabled={lessons.length === 0}>
            <Upload className="h-4 w-4 ml-2" />
            رفع ملف جديد
          </Button>
        </div>

        {lessons.length === 0 && (
          <p className="text-center text-muted-foreground py-8">يجب إضافة درس أولاً قبل رفع الملفات</p>
        )}

        {showFileForm && (
          <Card className="p-4 mb-6 bg-muted/50">
            <div className="space-y-4">
              <div>
                <Label>اختر الدرس</Label>
                <select
                  value={selectedLessonId}
                  onChange={(e) => setSelectedLessonId(e.target.value)}
                  className="w-full p-2 border rounded"
                >
                  <option value="">-- اختر درس --</option>
                  {lessons.map((lesson) => (
                    <option key={lesson.id} value={lesson.id}>
                      {lesson.title}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <Label>عنوان الملف</Label>
                <Input
                  value={fileForm.title}
                  onChange={(e) => setFileForm({ ...fileForm, title: e.target.value })}
                  placeholder="مثال: مذكرة الدرس الأول"
                />
              </div>
              <div>
                <Label>رابط الملف</Label>
                <Input
                  value={fileForm.file_url}
                  onChange={(e) => setFileForm({ ...fileForm, file_url: e.target.value })}
                  placeholder="https://drive.google.com/... أو رابط آخر"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  يمكنك رفع الملف على Google Drive أو Dropbox ثم لصق الرابط هنا
                </p>
              </div>
              <div>
                <Label>نوع الملف</Label>
                <select
                  value={fileForm.file_type}
                  onChange={(e) => setFileForm({ ...fileForm, file_type: e.target.value })}
                  className="w-full p-2 border rounded"
                >
                  <option value="pdf">PDF</option>
                  <option value="doc">Word Document</option>
                  <option value="ppt">PowerPoint</option>
                  <option value="other">أخرى</option>
                </select>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleSaveFile}>رفع الملف</Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowFileForm(false)
                    setFileForm({ title: "", file_url: "", file_type: "pdf" })
                    setSelectedLessonId("")
                  }}
                >
                  إلغاء
                </Button>
              </div>
            </div>
          </Card>
        )}

        <div className="space-y-3">
          {files.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد ملفات بعد</p>
          ) : (
            files.map((file) => {
              const lesson = lessons.find((l) => l.id === file.lesson_id)
              return (
                <Card key={file.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h3 className="font-semibold mb-1">{file.title}</h3>
                      <p className="text-sm text-muted-foreground">الدرس: {lesson?.title || "غير محدد"}</p>
                      <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded inline-block mt-2">
                        {file.file_type.toUpperCase()}
                      </span>
                    </div>
                    <div className="flex gap-2">
                      <a href={file.file_url} target="_blank" rel="noopener noreferrer">
                        <Button variant="outline" size="sm">
                          <FileText className="h-4 w-4 ml-1" />
                          فتح الملف
                        </Button>
                      </a>
                      <Button variant="destructive" size="icon" onClick={() => handleDeleteFile(file.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              )
            })
          )}
        </div>
      </Card>
    </div>
  )
}
