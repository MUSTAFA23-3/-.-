"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Save, Phone, Mail, MapPin, Facebook } from "lucide-react"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { toast } from "sonner"

type ContactInfo = {
  id: string
  phone: string | null
  email: string | null
  facebook_url: string | null
  address: string | null
}

export function ContactManager({ initialContact }: { initialContact: ContactInfo | null }) {
  const [contact, setContact] = useState<ContactInfo>(
    initialContact || {
      id: "",
      phone: "",
      email: "",
      facebook_url: "",
      address: "",
    },
  )
  const [isEditing, setIsEditing] = useState(false)
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()

  const handleSave = async () => {
    const { error } = await supabase.from("contact_info").upsert(contact)

    if (error) {
      toast.error("حدث خطأ أثناء الحفظ")
      return
    }

    toast.success("تم تحديث معلومات التواصل بنجاح")
    setIsEditing(false)
    router.refresh()
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">معلومات التواصل</h2>
          <p className="text-gray-600 mt-1">تحديث بيانات الاتصال المعروضة في الموقع</p>
        </div>
        {!isEditing && (
          <Button onClick={() => setIsEditing(true)} className="bg-gradient-to-r from-emerald-600 to-teal-600">
            تعديل المعلومات
          </Button>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>بيانات الاتصال</CardTitle>
          <CardDescription>قم بتحديث معلومات التواصل التي تظهر للزوار</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="phone">رقم الهاتف</Label>
            <div className="relative">
              <Phone className="absolute right-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="phone"
                value={contact.phone || ""}
                onChange={(e) => setContact({ ...contact, phone: e.target.value })}
                disabled={!isEditing}
                className="pr-10"
                dir="ltr"
                placeholder="01XXXXXXXXX"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">البريد الإلكتروني</Label>
            <div className="relative">
              <Mail className="absolute right-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="email"
                type="email"
                value={contact.email || ""}
                onChange={(e) => setContact({ ...contact, email: e.target.value })}
                disabled={!isEditing}
                className="pr-10"
                dir="ltr"
                placeholder="example@email.com"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="facebook">رابط صفحة الفيسبوك</Label>
            <div className="relative">
              <Facebook className="absolute right-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="facebook"
                value={contact.facebook_url || ""}
                onChange={(e) => setContact({ ...contact, facebook_url: e.target.value })}
                disabled={!isEditing}
                className="pr-10"
                dir="ltr"
                placeholder="https://www.facebook.com/..."
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">العنوان</Label>
            <div className="relative">
              <MapPin className="absolute right-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="address"
                value={contact.address || ""}
                onChange={(e) => setContact({ ...contact, address: e.target.value })}
                disabled={!isEditing}
                className="pr-10"
                placeholder="مصر"
              />
            </div>
          </div>

          {isEditing && (
            <div className="flex justify-end gap-2 pt-4 border-t">
              <Button variant="outline" onClick={() => setIsEditing(false)}>
                إلغاء
              </Button>
              <Button onClick={handleSave} className="bg-gradient-to-r from-emerald-600 to-teal-600">
                <Save className="w-4 h-4 ml-2" />
                حفظ التغييرات
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
