"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Save, Award, TrendingUp, Users } from "lucide-react"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { toast } from "sonner"

type Stats = {
  id: string
  years_experience: number
  success_rate: number
  students_count: number
}

export function StatsManager({ initialStats }: { initialStats: Stats | null }) {
  const [stats, setStats] = useState<Stats>(
    initialStats || {
      id: "",
      years_experience: 20,
      success_rate: 98,
      students_count: 5000,
    },
  )
  const [isEditing, setIsEditing] = useState(false)
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()

  const handleSave = async () => {
    const { error } = await supabase.from("site_stats").upsert(stats)

    if (error) {
      toast.error("حدث خطأ أثناء الحفظ")
      return
    }

    toast.success("تم تحديث الإحصائيات بنجاح")
    setIsEditing(false)
    router.refresh()
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">إحصائيات الموقع</h2>
          <p className="text-gray-600 mt-1">تحديث الأرقام المعروضة في الصفحة الرئيسية</p>
        </div>
        {!isEditing && (
          <Button onClick={() => setIsEditing(true)} className="bg-gradient-to-r from-emerald-600 to-teal-600">
            تعديل الإحصائيات
          </Button>
        )}
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-gray-600">سنوات الخبرة</CardTitle>
              <Award className="w-5 h-5 text-emerald-600" />
            </div>
          </CardHeader>
          <CardContent>
            {isEditing ? (
              <div className="space-y-2">
                <Input
                  type="number"
                  value={stats.years_experience}
                  onChange={(e) => setStats({ ...stats, years_experience: Number.parseInt(e.target.value) || 0 })}
                />
              </div>
            ) : (
              <>
                <div className="text-3xl font-bold text-gray-900">{stats.years_experience}</div>
                <p className="text-xs text-gray-500 mt-1">في تدريس الأحياء والجيولوجيا</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-gray-600">نسبة النجاح</CardTitle>
              <TrendingUp className="w-5 h-5 text-emerald-600" />
            </div>
          </CardHeader>
          <CardContent>
            {isEditing ? (
              <div className="space-y-2">
                <Input
                  type="number"
                  value={stats.success_rate}
                  onChange={(e) => setStats({ ...stats, success_rate: Number.parseInt(e.target.value) || 0 })}
                  max={100}
                />
                <p className="text-xs text-gray-500">القيمة من 0 إلى 100</p>
              </div>
            ) : (
              <>
                <div className="text-3xl font-bold text-gray-900">{stats.success_rate}%</div>
                <p className="text-xs text-gray-500 mt-1">من الطلاب الناجحين</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-gray-600">عدد الطلاب</CardTitle>
              <Users className="w-5 h-5 text-emerald-600" />
            </div>
          </CardHeader>
          <CardContent>
            {isEditing ? (
              <div className="space-y-2">
                <Input
                  type="number"
                  value={stats.students_count}
                  onChange={(e) => setStats({ ...stats, students_count: Number.parseInt(e.target.value) || 0 })}
                />
              </div>
            ) : (
              <>
                <div className="text-3xl font-bold text-gray-900">{stats.students_count.toLocaleString("ar-EG")}</div>
                <p className="text-xs text-gray-500 mt-1">طالب وطالبة</p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {isEditing && (
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsEditing(false)}>
                إلغاء
              </Button>
              <Button onClick={handleSave} className="bg-gradient-to-r from-emerald-600 to-teal-600">
                <Save className="w-4 h-4 ml-2" />
                حفظ التغييرات
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
