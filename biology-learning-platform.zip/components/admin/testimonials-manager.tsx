"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Plus, Save, Trash2, Star } from "lucide-react"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { toast } from "sonner"

type Testimonial = {
  id: string
  student_name: string
  content: string
  rating: number
  year: string | null
  is_active: boolean
}

export function TestimonialsManager({ initialTestimonials }: { initialTestimonials: Testimonial[] }) {
  const [testimonials, setTestimonials] = useState<Testimonial[]>(initialTestimonials)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [isAdding, setIsAdding] = useState(false)
  const [newTestimonial, setNewTestimonial] = useState({
    student_name: "",
    content: "",
    rating: 5,
    year: "",
    is_active: true,
  })
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()

  const handleUpdate = async (testimonial: Testimonial) => {
    const { error } = await supabase.from("testimonials").update(testimonial).eq("id", testimonial.id)

    if (error) {
      toast.error("حدث خطأ أثناء التحديث")
      return
    }

    toast.success("تم تحديث الرأي بنجاح")
    setEditingId(null)
    router.refresh()
  }

  const handleAdd = async () => {
    const { error } = await supabase.from("testimonials").insert(newTestimonial)

    if (error) {
      toast.error("حدث خطأ أثناء الإضافة")
      return
    }

    toast.success("تم إضافة الرأي بنجاح")
    setIsAdding(false)
    setNewTestimonial({ student_name: "", content: "", rating: 5, year: "", is_active: true })
    router.refresh()
  }

  const handleDelete = async (id: string) => {
    if (!confirm("هل أنت متأكد من حذف هذا الرأي؟")) return

    const { error } = await supabase.from("testimonials").delete().eq("id", id)

    if (error) {
      toast.error("حدث خطأ أثناء الحذف")
      return
    }

    toast.success("تم حذف الرأي بنجاح")
    router.refresh()
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">آراء الطلاب</h2>
          <p className="text-gray-600 mt-1">إدارة تقييمات وشهادات الطلاب</p>
        </div>
        <Button onClick={() => setIsAdding(true)} className="bg-gradient-to-r from-emerald-600 to-teal-600">
          <Plus className="w-4 h-4 ml-2" />
          إضافة رأي جديد
        </Button>
      </div>

      {isAdding && (
        <Card>
          <CardHeader>
            <CardTitle>إضافة رأي جديد</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="new-name">اسم الطالب</Label>
                <Input
                  id="new-name"
                  value={newTestimonial.student_name}
                  onChange={(e) => setNewTestimonial({ ...newTestimonial, student_name: e.target.value })}
                  placeholder="محمد أحمد"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-year">السنة الدراسية (اختياري)</Label>
                <Input
                  id="new-year"
                  value={newTestimonial.year}
                  onChange={(e) => setNewTestimonial({ ...newTestimonial, year: e.target.value })}
                  placeholder="2024"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-content">محتوى الرأي</Label>
              <Textarea
                id="new-content"
                value={newTestimonial.content}
                onChange={(e) => setNewTestimonial({ ...newTestimonial, content: e.target.value })}
                placeholder="كتابة رأي الطالب..."
                rows={4}
              />
            </div>
            <div className="space-y-2">
              <Label>التقييم</Label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setNewTestimonial({ ...newTestimonial, rating: star })}
                    className="focus:outline-none"
                  >
                    <Star
                      className={`w-6 h-6 ${star <= newTestimonial.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
                    />
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center justify-between pt-4 border-t">
              <div className="flex items-center gap-2">
                <Switch
                  checked={newTestimonial.is_active}
                  onCheckedChange={(checked) => setNewTestimonial({ ...newTestimonial, is_active: checked })}
                />
                <Label>نشط</Label>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsAdding(false)}>
                  إلغاء
                </Button>
                <Button onClick={handleAdd} disabled={!newTestimonial.student_name || !newTestimonial.content}>
                  إضافة
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {testimonials.map((testimonial) => (
          <Card key={testimonial.id}>
            <CardContent className="pt-6">
              {editingId === testimonial.id ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>اسم الطالب</Label>
                      <Input
                        value={testimonial.student_name}
                        onChange={(e) =>
                          setTestimonials(
                            testimonials.map((t) =>
                              t.id === testimonial.id ? { ...t, student_name: e.target.value } : t,
                            ),
                          )
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>السنة الدراسية</Label>
                      <Input
                        value={testimonial.year || ""}
                        onChange={(e) =>
                          setTestimonials(
                            testimonials.map((t) => (t.id === testimonial.id ? { ...t, year: e.target.value } : t)),
                          )
                        }
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>محتوى الرأي</Label>
                    <Textarea
                      value={testimonial.content}
                      onChange={(e) =>
                        setTestimonials(
                          testimonials.map((t) => (t.id === testimonial.id ? { ...t, content: e.target.value } : t)),
                        )
                      }
                      rows={4}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>التقييم</Label>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() =>
                            setTestimonials(
                              testimonials.map((t) => (t.id === testimonial.id ? { ...t, rating: star } : t)),
                            )
                          }
                          className="focus:outline-none"
                        >
                          <Star
                            className={`w-6 h-6 ${star <= testimonial.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={testimonial.is_active}
                        onCheckedChange={(checked) =>
                          setTestimonials(
                            testimonials.map((t) => (t.id === testimonial.id ? { ...t, is_active: checked } : t)),
                          )
                        }
                      />
                      <Label>نشط</Label>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" onClick={() => setEditingId(null)}>
                        إلغاء
                      </Button>
                      <Button onClick={() => handleUpdate(testimonial)}>
                        <Save className="w-4 h-4 ml-2" />
                        حفظ
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-gray-900">{testimonial.student_name}</h3>
                      {testimonial.year && (
                        <span className="px-2 py-1 text-xs bg-emerald-100 text-emerald-700 rounded">
                          {testimonial.year}
                        </span>
                      )}
                      {!testimonial.is_active && (
                        <span className="px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded">غير نشط</span>
                      )}
                    </div>
                    <p className="text-gray-600 mb-2">{testimonial.content}</p>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-4 h-4 ${star <= testimonial.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => setEditingId(testimonial.id)}>
                      تعديل
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(testimonial.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
