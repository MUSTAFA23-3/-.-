import { Facebook } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-card border-t border-border py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="text-2xl font-bold text-primary mb-4">منصة الأحياء</h3>
              <p className="text-muted-foreground leading-relaxed">
                منصة تعليمية متخصصة في الأحياء والجيولوجيا مع خبرة 20 سنة في التدريس
              </p>
            </div>

            <div>
              <h4 className="font-semibold text-lg mb-4 text-foreground">الدورات</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>الدعامة والحركة</li>
                <li>التنسيق الهرموني</li>
                <li>التكاثر</li>
                <li>المناعة</li>
                <li>DNA + RNA</li>
                <li>جيولوجيا</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-lg mb-4 text-foreground">تواصل معنا</h4>
              <div className="space-y-3">
                <p className="text-muted-foreground">العنوان: مصر</p>
                <a
                  href="https://www.facebook.com/share/14TvrKoPeQV/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors"
                >
                  <Facebook className="h-5 w-5" />
                  <span>تابعنا على فيسبوك</span>
                </a>
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-border text-center">
            <p className="text-muted-foreground font-sans">© 2025 منصة أ.محمد زايد. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </div>
    </footer>
  )
}
