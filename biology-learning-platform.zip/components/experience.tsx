import { Award, BookOpen, Users, Trophy } from "lucide-react"

export default function Experience() {
  const stats = [
    {
      icon: Award,
      value: "20+",
      label: "سنة خبرة",
    },
    {
      icon: Users,
      value: "1000+",
      label: "طالب متفوق",
    },
    {
      icon: BookOpen,
      value: "6",
      label: "دورات متخصصة",
    },
    {
      icon: Trophy,
      value: "98%",
      label: "نسبة نجاح",
    },
  ]

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="flex flex-col items-center justify-center p-6 bg-card rounded-xl shadow-lg hover:shadow-xl transition-shadow border border-border"
            >
              <stat.icon className="h-12 w-12 text-primary mb-4" />
              <div className="text-4xl font-bold text-primary mb-2">{stat.value}</div>
              <div className="text-sm text-muted-foreground text-center">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
