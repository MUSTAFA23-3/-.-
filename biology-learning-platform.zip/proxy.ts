import { NextResponse, type NextRequest } from "next/server"

export async function proxy(request: NextRequest) {
  const adminSession = request.cookies.get("admin_session")

  // Protect admin routes
  if (request.nextUrl.pathname.startsWith("/admin") && !request.nextUrl.pathname.startsWith("/admin/login")) {
    if (!adminSession) {
      const redirectUrl = new URL("/admin/login", request.url)
      return NextResponse.redirect(redirectUrl)
    }
  }

  // Redirect to dashboard if already logged in
  if (request.nextUrl.pathname === "/admin/login" && adminSession) {
    const redirectUrl = new URL("/admin", request.url)
    return NextResponse.redirect(redirectUrl)
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/admin/:path*"],
}
