import bcrypt

# The password we want to hash
password = "Admin@123456"

# Generate salt and hash the password
salt = bcrypt.gensalt(rounds=10)
password_hash = bcrypt.hashpw(password.encode('utf-8'), salt)

# Print the hash (this will be used in the SQL update)
print("Password Hash for 'Admin@123456':")
print(password_hash.decode('utf-8'))

# Verify it works
is_correct = bcrypt.checkpw(password.encode('utf-8'), password_hash)
print(f"\nVerification test: {is_correct}")
