-- Create admins table for admin users
CREATE TABLE IF NOT EXISTS admins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  name TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create courses table
CREATE TABLE IF NOT EXISTS courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  icon_name TEXT NOT NULL,
  order_index INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create testimonials table
CREATE TABLE IF NOT EXISTS testimonials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_name TEXT NOT NULL,
  content TEXT NOT NULL,
  rating INTEGER DEFAULT 5,
  year TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create stats table for website statistics
CREATE TABLE IF NOT EXISTS site_stats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  years_experience INTEGER DEFAULT 20,
  success_rate INTEGER DEFAULT 98,
  students_count INTEGER DEFAULT 5000,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create contact_info table
CREATE TABLE IF NOT EXISTS contact_info (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone TEXT,
  email TEXT,
  facebook_url TEXT,
  address TEXT,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default admin (password: Admin@123456)
-- Password hash generated using bcrypt for 'Admin@123456'
INSERT INTO admins (email, password_hash, name) 
VALUES (
  '01148766696m@gmail.com',
  '$2a$10$rXK7qGKJ3LFx5fHdVQN4FuGxEqJYHLzXVpqE8N4MN5wLYPjVKZX3G',
  'المدير'
) ON CONFLICT (email) DO NOTHING;

-- Insert default courses
INSERT INTO courses (title, description, icon_name, order_index) VALUES
  ('الدعامة والحركة', 'دراسة شاملة للجهاز الحركي والعظمي والعضلي', 'bone', 1),
  ('التنسيق الهرموني', 'فهم عميق لنظام الغدد الصماء والهرمونات', 'activity', 2),
  ('التكاثر', 'دراسة مفصلة للجهاز التناسلي والتكاثر البشري', 'dna', 3),
  ('المناعة', 'استكشاف جهاز المناعة ودفاعات الجسم', 'shield', 4),
  ('DNA + RNA', 'علم الوراثة الجزيئية والأحماض النووية', 'dna', 5),
  ('جيولوجيا', 'دراسة الأرض وتكوينها والعمليات الجيولوجية', 'mountain', 6)
ON CONFLICT DO NOTHING;

-- Insert default stats
INSERT INTO site_stats (years_experience, success_rate, students_count) 
VALUES (20, 98, 5000)
ON CONFLICT DO NOTHING;

-- Insert default contact info
INSERT INTO contact_info (phone, email, facebook_url, address) 
VALUES (
  '01148766696',
  '01148766696m@gmail.com',
  'https://www.facebook.com/share/14TvrKoPeQV/',
  'مصر'
) ON CONFLICT DO NOTHING;

-- Enable Row Level Security
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE testimonials ENABLE ROW LEVEL SECURITY;
ALTER TABLE site_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE contact_info ENABLE ROW LEVEL SECURITY;

-- Create policies for public read access
CREATE POLICY "Public can read courses" ON courses FOR SELECT USING (is_active = true);
CREATE POLICY "Public can read testimonials" ON testimonials FOR SELECT USING (is_active = true);
CREATE POLICY "Public can read stats" ON site_stats FOR SELECT USING (true);
CREATE POLICY "Public can read contact" ON contact_info FOR SELECT USING (true);

-- Admin policies (authenticated users can do everything)
CREATE POLICY "Admins can do everything on courses" ON courses FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can do everything on testimonials" ON testimonials FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can do everything on stats" ON site_stats FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can do everything on contact" ON contact_info FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can read admins" ON admins FOR SELECT USING (auth.role() = 'authenticated');
