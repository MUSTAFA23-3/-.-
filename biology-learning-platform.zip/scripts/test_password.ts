import bcrypt from "bcryptjs"

const password = "Admin@123456"
const existingHash = "$2b$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW"

console.log("Testing password:", password)
console.log("Existing hash:", existingHash)

// Test if existing hash works
bcrypt.compare(password, existingHash).then((result) => {
  console.log("Does existing hash match?", result)
})

// Generate a new hash
bcrypt.hash(password, 10).then((newHash) => {
  console.log("\nNew hash generated:", newHash)

  // Test the new hash
  bcrypt.compare(password, newHash).then((result) => {
    console.log("Does new hash match?", result)
  })
})
