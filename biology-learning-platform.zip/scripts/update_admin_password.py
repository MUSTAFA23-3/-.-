import bcrypt
import os

# Password to hash
password = "Admin@123456"

# Generate hash
salt = bcrypt.gensalt(rounds=10)
password_hash = bcrypt.hashpw(password.encode('utf-8'), salt)

# Print the hash (you'll use this in SQL)
print("Generated password hash:")
print(password_hash.decode('utf-8'))

# Test the hash
test_result = bcrypt.checkpw(password.encode('utf-8'), password_hash)
print(f"\nPassword verification test: {test_result}")
