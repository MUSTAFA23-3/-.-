import Hero from "@/components/hero"
import Courses from "@/components/courses"
import Experience from "@/components/experience"
import Contact from "@/components/contact"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <Experience />
      <Courses />
      <Contact />
      <Footer />
    </main>
  )
}
