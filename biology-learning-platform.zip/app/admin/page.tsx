import { redirect } from "next/navigation"
import { getSession, signOut } from "@/lib/auth"
import { getSupabaseServerClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  GraduationCap,
  BookOpen,
  MessageSquare,
  BarChart3,
  Settings,
  LogOut,
  Users,
  Award,
  TrendingUp,
} from "lucide-react"
import Link from "next/link"

async function getStats() {
  const supabase = await getSupabaseServerClient()

  const [courses, testimonials, stats] = await Promise.all([
    supabase.from("courses").select("*", { count: "exact" }),
    supabase.from("testimonials").select("*", { count: "exact" }),
    supabase.from("site_stats").select("*").single(),
  ])

  return {
    coursesCount: courses.count || 0,
    testimonialsCount: testimonials.count || 0,
    stats: stats.data,
  }
}

export default async function AdminDashboard() {
  const session = await getSession()

  if (!session) {
    redirect("/admin/login")
  }

  const { coursesCount, testimonialsCount, stats } = await getStats()

  const cards = [
    {
      title: "الدورات التعليمية",
      description: "إدارة المحتوى التعليمي",
      icon: BookOpen,
      value: coursesCount,
      href: "/admin/courses",
      color: "from-blue-500 to-blue-600",
    },
    {
      title: "آراء الطلاب",
      description: "إدارة التقييمات والشهادات",
      icon: MessageSquare,
      value: testimonialsCount,
      href: "/admin/testimonials",
      color: "from-purple-500 to-purple-600",
    },
    {
      title: "الإحصائيات",
      description: "تحديث أرقام الموقع",
      icon: BarChart3,
      value: stats?.students_count || 0,
      label: "طالب",
      href: "/admin/stats",
      color: "from-emerald-500 to-emerald-600",
    },
    {
      title: "معلومات التواصل",
      description: "تحديث بيانات الاتصال",
      icon: Settings,
      href: "/admin/contact",
      color: "from-orange-500 to-orange-600",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50" dir="rtl">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-600 to-teal-600 rounded-full flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">لوحة التحكم الإدارية</h1>
                <p className="text-sm text-gray-500">منصة دراسة الأحياء والجيولوجيا</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/" target="_blank">
                <Button variant="outline" size="sm">
                  عرض الموقع
                </Button>
              </Link>
              <form action={signOut}>
                <Button
                  type="submit"
                  variant="outline"
                  size="sm"
                  className="text-red-600 hover:text-red-700 hover:bg-red-50 bg-transparent"
                >
                  <LogOut className="w-4 h-4 ml-2" />
                  تسجيل الخروج
                </Button>
              </form>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">سنوات الخبرة</CardTitle>
              <Award className="w-5 h-5 text-emerald-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-900">{stats?.years_experience || 20}</div>
              <p className="text-xs text-gray-500 mt-1">في تدريس الأحياء والجيولوجيا</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">نسبة النجاح</CardTitle>
              <TrendingUp className="w-5 h-5 text-emerald-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-900">{stats?.success_rate || 98}%</div>
              <p className="text-xs text-gray-500 mt-1">من الطلاب الناجحين</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">عدد الطلاب</CardTitle>
              <Users className="w-5 h-5 text-emerald-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-900">
                {stats?.students_count?.toLocaleString("ar-EG") || "5,000"}
              </div>
              <p className="text-xs text-gray-500 mt-1">طالب وطالبة</p>
            </CardContent>
          </Card>
        </div>

        {/* Management Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {cards.map((card) => (
            <Link key={card.title} href={card.href}>
              <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg mb-2">{card.title}</CardTitle>
                      <CardDescription>{card.description}</CardDescription>
                    </div>
                    <div
                      className={`w-12 h-12 rounded-lg bg-gradient-to-br ${card.color} flex items-center justify-center`}
                    >
                      <card.icon className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardHeader>
                {card.value !== undefined && (
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">
                      {card.value}
                      {card.label && <span className="text-lg text-gray-600 mr-2">{card.label}</span>}
                    </div>
                  </CardContent>
                )}
              </Card>
            </Link>
          ))}
        </div>
      </main>
    </div>
  )
}
