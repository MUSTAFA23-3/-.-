import { redirect } from "next/navigation"
import { getSession } from "@/lib/auth"
import { getSupabaseServerClient } from "@/lib/supabase/server"
import { AdminHeader } from "@/components/admin/admin-header"
import { CoursesManager } from "@/components/admin/courses-manager"

async function getCourses() {
  const supabase = await getSupabaseServerClient()
  const { data: courses, error } = await supabase.from("courses").select("*").order("order_index", { ascending: true })

  if (error) {
    console.error("Error fetching courses:", error)
    return []
  }

  return courses
}

export default async function CoursesPage() {
  const session = await getSession()

  if (!session) {
    redirect("/admin/login")
  }

  const courses = await getCourses()

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50" dir="rtl">
      <AdminHeader title="إدارة الدورات التعليمية" />
      <main className="container mx-auto px-4 py-8">
        <CoursesManager initialCourses={courses} />
      </main>
    </div>
  )
}
