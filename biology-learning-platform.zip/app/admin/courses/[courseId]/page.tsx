import { Suspense } from "react"
import { CourseContentManager } from "@/components/admin/course-content-manager"

export default function CourseContentPage({ params }: { params: { courseId: string } }) {
  return (
    <div className="container mx-auto py-8 px-4">
      <Suspense fallback={<div className="text-center">جاري التحميل...</div>}>
        <CourseContentManager courseId={params.courseId} />
      </Suspense>
    </div>
  )
}
