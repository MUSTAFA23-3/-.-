import { redirect } from "next/navigation"
import { getSession } from "@/lib/auth"
import { getSupabaseServerClient } from "@/lib/supabase/server"
import { AdminHeader } from "@/components/admin/admin-header"
import { StatsManager } from "@/components/admin/stats-manager"

async function getStats() {
  const supabase = await getSupabaseServerClient()
  const { data: stats, error } = await supabase.from("site_stats").select("*").single()

  if (error) {
    console.error("Error fetching stats:", error)
    return null
  }

  return stats
}

export default async function StatsPage() {
  const session = await getSession()

  if (!session) {
    redirect("/admin/login")
  }

  const stats = await getStats()

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50" dir="rtl">
      <AdminHeader title="إدارة الإحصائيات" />
      <main className="container mx-auto px-4 py-8">
        <StatsManager initialStats={stats} />
      </main>
    </div>
  )
}
