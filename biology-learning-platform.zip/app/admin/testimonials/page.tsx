import { redirect } from "next/navigation"
import { getSession } from "@/lib/auth"
import { getSupabaseServerClient } from "@/lib/supabase/server"
import { AdminHeader } from "@/components/admin/admin-header"
import { TestimonialsManager } from "@/components/admin/testimonials-manager"

async function getTestimonials() {
  const supabase = await getSupabaseServerClient()
  const { data: testimonials, error } = await supabase
    .from("testimonials")
    .select("*")
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching testimonials:", error)
    return []
  }

  return testimonials
}

export default async function TestimonialsPage() {
  const session = await getSession()

  if (!session) {
    redirect("/admin/login")
  }

  const testimonials = await getTestimonials()

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50" dir="rtl">
      <AdminHeader title="إدارة آراء الطلاب" />
      <main className="container mx-auto px-4 py-8">
        <TestimonialsManager initialTestimonials={testimonials} />
      </main>
    </div>
  )
}
