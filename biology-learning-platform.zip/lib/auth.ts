"use server"

import { getSupabaseServerClient } from "./supabase/server"
import { cookies } from "next/headers"
import bcrypt from "bcryptjs"

export async function signIn(email: string, password: string) {
  console.log("[v0] ========== بدء عملية تسجيل الدخول ==========")
  console.log("[v0] البريد المدخل:", email)
  console.log("[v0] طول كلمة المرور:", password.length)

  const supabase = await getSupabaseServerClient()

  // Get admin from database
  const { data: admin, error } = await supabase.from("admins").select("*").eq("email", email).single()

  console.log("[v0] نتيجة الاستعلام من قاعدة البيانات:")
  console.log("[v0] - البريد من قاعدة البيانات:", admin?.email)
  console.log("[v0] - هل يوجد خطأ:", !!error)
  console.log("[v0] - تفاصيل الخطأ:", error)

  if (error || !admin) {
    console.log("[v0] ❌ المستخدم غير موجود في قاعدة البيانات")
    return { error: "بيانات تسجيل الدخول غير صحيحة" }
  }

  console.log("[v0] ✓ تم العثور على المستخدم")
  console.log("[v0] - الهاش المحفوظ:", admin.password_hash)
  console.log("[v0] - كلمة المرور المدخلة:", password)
  console.log("[v0] بدء مقارنة كلمة المرور...")

  // Verify password
  try {
    const isValid = await bcrypt.compare(password, admin.password_hash)
    console.log("[v0] نتيجة المقارنة:", isValid)

    if (!isValid) {
      console.log("[v0] ❌ كلمة المرور غير صحيحة")
      return { error: "بيانات تسجيل الدخول غير صحيحة" }
    }

    console.log("[v0] ✓ كلمة المرور صحيحة")
  } catch (compareError) {
    console.log("[v0] ❌ خطأ في مقارنة كلمة المرور:", compareError)
    return { error: "حدث خطأ أثناء التحقق من كلمة المرور" }
  }

  // Set session cookie
  try {
    const cookieStore = await cookies()
    cookieStore.set("admin_session", admin.id, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 7 days
      path: "/",
    })

    console.log("[v0] ✓ تم إنشاء الجلسة بنجاح")
    console.log("[v0] ========== تم تسجيل الدخول بنجاح ==========")

    return { success: true }
  } catch (cookieError) {
    console.log("[v0] ❌ خطأ في إنشاء الجلسة:", cookieError)
    return { error: "حدث خطأ أثناء إنشاء الجلسة" }
  }
}

export async function signOut() {
  const cookieStore = await cookies()
  cookieStore.delete("admin_session")
}

export async function getSession() {
  const cookieStore = await cookies()
  const sessionCookie = cookieStore.get("admin_session")

  if (!sessionCookie) {
    return null
  }

  const supabase = await getSupabaseServerClient()
  const { data: admin } = await supabase.from("admins").select("*").eq("id", sessionCookie.value).single()

  return admin
}
